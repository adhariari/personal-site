<?php
	header('location:');
?>