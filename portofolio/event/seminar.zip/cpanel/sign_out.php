<?php
	session_unset();
	session_destroy();
	echo "<script>alert('Anda menuju halaman utama'); location.href='http://eventgunadarma.web.id'</script>";
	exit;
?>