<?php
	include "../conf/koneksi.php";
	include "../lib/inc.session.php";
	
	mysqli_query($connect, "DELETE FROM seminar WHERE token_seminar = '$_GET[tid]' ");
	
	echo "<meta http-equiv='refresh' content='0;url=?page=vwSmnr'>";
?>